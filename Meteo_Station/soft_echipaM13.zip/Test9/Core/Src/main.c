/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>      // add for printf
#include <string.h>
#include "i2c_lcd.h" //Am adaugat pentru lcd

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c2;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
#define SW_VERSION 11
static const uint8_t AHT21_ADDR = 0x38 << 1; // datasheet
uint8_t uart_buf[1]; // un octet care salveaza o valoare pe care o trimitem/primim prin UART
uint8_t ticks=0;  // timer2 ticks
uint8_t SM_State; // State for the State Machine

uint8_t variable_full_green = 0; // 1 = full verde 

uint8_t variable_blink_blue = 0; // STAREA 4 1 = speed vary
#define BLUE_BLINK_MAX 30  // pauza maxima intre ON/OFF (lent)
#define BLUE_BLINK_MIN 2    // pauza minima (rapida)
uint8_t blue_led_state = 0;
uint8_t blue_blink_ticks = 0;
uint8_t blue_blink_delay = BLUE_BLINK_MIN;  // incetineste rapid
uint8_t blue_blink_dir = 1;  //  +2 = incetineste, -2 = accelereaza

volatile uint8_t btn_locked = 0;
volatile uint32_t last_press_time = 0; 
volatile uint8_t measure_flag = 0;

volatile uint8_t breathe_mode = 0;
volatile uint8_t breathe_dir = 1;  // 1 = creste, 0 = scade
volatile uint8_t breathe_pwm = 0;
uint8_t initialized_breathe = 0;

volatile uint8_t display_mode = 0;
volatile uint8_t btn_display_locked = 0;  //astea sunt pentru butonul de schimbat afisajul
volatile uint32_t last_display_press_time = 0;
volatile uint8_t display_mode_changed = 0;

volatile uint8_t led_on = 1; 

float temp_c = 0.0f;
float humidity = 0.0f;


uint8_t initialized_blue_blink = 0; // ca sa nu se reinitializeze de fiecare data cand se citeste o noua temperatura/hum

volatile uint32_t pulse_count = 0;

float viteza_medie = 0.0f;
float viteza_max = 0.0f;
float viteza_min = 0.0f;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_I2C2_Init(void);

/* USER CODE BEGIN PFP */

void reset_led_effects(void);   // PRIVATE FUNCTION PROTOTYPES

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif

/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE
{
  HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF);
  return ch;
}

/* also redefine _write for printf*/
int _write(int fd, char * ptr, int len)
{
  HAL_UART_Transmit(&huart1, (uint8_t *) ptr, len, HAL_MAX_DELAY);
  return len;
}


/* Callback function for UART RX Complete: process incoming character*/
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if(uart_buf[0] != '?' && uart_buf[0] != '!') {
    uart_buf[0]++;  
    HAL_UART_Transmit(&huart1, uart_buf, 1, 10);
  }
  else if(uart_buf[0] != '?' && uart_buf[0] == '!'){
    printf("M13: Cosmin + Denisa\r\n");
  }
  else 
    printf("Sw Version %d.%d\r\n",SW_VERSION/10, SW_VERSION%10);
  
  HAL_UART_Receive_IT(&huart1, uart_buf, 1); // reactivate interrupt for next char
}

/* Timer2 Interrupt Service Routine: Blinks LEDs */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  static uint16_t temp_ticks = 0; 
  if (++temp_ticks >= 100) { 
      measure_flag = 1;
      temp_ticks = 0;
  }

  if(variable_full_green == 1) {
      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, 1); 
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 0); 
  }
  else if(variable_blink_blue == 1) {
    blue_blink_ticks++; 

    if (blue_blink_ticks >= blue_blink_delay)
    {
      blue_blink_ticks = 0;
      blue_led_state = !blue_led_state;
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, blue_led_state); 
      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, 0); 
      blue_blink_delay += blue_blink_dir * 2;

      if (blue_blink_delay >= BLUE_BLINK_MAX) {
            blue_blink_delay = BLUE_BLINK_MAX;
            blue_blink_dir = -1;
      } else if (blue_blink_delay <= BLUE_BLINK_MIN) {
            blue_blink_delay = BLUE_BLINK_MIN;
            blue_blink_dir = 1; 
      }
    }
  }

  if (breathe_mode==1) {
    if (breathe_dir==1)
      breathe_pwm+=2;
    else
      breathe_pwm-=2;

    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, breathe_pwm);

    if (breathe_pwm == 254)
      breathe_dir = 0;
    else if (breathe_pwm == 0)
      breathe_dir = 1;
  }
}



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /****************************************************************************/
  /********************************      MAIN        **************************/
  /****************************************************************************/



  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USB_DEVICE_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_I2C2_Init();
  /* USER CODE BEGIN 2 */

  HAL_UART_Receive_IT(&huart1, uart_buf, 1);
  HAL_TIM_Base_Start_IT(&htim2);

  lcd_init();
  lcd_put_cursor(0, 0);
  lcd_send_string("Hello, Deni!");
  lcd_put_cursor(1, 0);
  lcd_send_string("Hello, Cos!");

  HAL_Delay(2000);
  lcd_clear();
  
  uint8_t status_cmd = 0x71;
  uint8_t status;
  if (HAL_I2C_Master_Transmit(&hi2c2, AHT21_ADDR, &status_cmd, 1, HAL_MAX_DELAY) != HAL_OK ||
      HAL_I2C_Master_Receive(&hi2c2, AHT21_ADDR, &status, 1, HAL_MAX_DELAY) != HAL_OK) {
      printf("STATUS read ERROR\r\n");
  } else {
      printf("STATUS = 0x%02X\r\n", status);
  }
  
  if ((status & 0x18) != 0x18) {
      uint8_t init_cmd[3] = {0x1B, 0x1C, 0x1E};
      if (HAL_I2C_Master_Transmit(&hi2c2, AHT21_ADDR, init_cmd, 3, HAL_MAX_DELAY) != HAL_OK) {
          printf("Init AHT21 failed!\r\n");
      } else {
          printf("Init AHT21 OK\r\n");
      }
      HAL_Delay(10);
  }
  
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  


  /*********************************** main loop *************************************************/
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    if (btn_locked == 1 && HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_SET) { // daca butonul a fost apasat virtual, dar in realitate nu mai este apasat  
      btn_locked = 0; 
    }

    if (btn_display_locked && HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12) == GPIO_PIN_SET) {
      btn_display_locked = 0; 
    }

    if (display_mode_changed) {
      lcd_clear();
      display_mode_changed = 0;
    }   

    if(measure_flag == 1) {
      measure_flag = 0;

      // pagina 12
      uint8_t cmd[3] = {0xAC, 0x33, 0x00};

      uint8_t data[6]; 

      // HAL_OK, HAL_ERROR, HAL_BUSY, HAL_TIMEOUT
      HAL_StatusTypeDef ret; 
      ret = HAL_I2C_Master_Transmit(&hi2c2, AHT21_ADDR, cmd, 3, HAL_MAX_DELAY);

      if (ret != HAL_OK) {
          printf("Error Transmit\r\n");
      } else {
          HAL_Delay(80);
              
          do {
              ret = HAL_I2C_Master_Receive(&hi2c2, AHT21_ADDR, data, 6, HAL_MAX_DELAY);
              if (ret != HAL_OK) {
                  printf("Error Receive\r\n");
                  break;
              }
              // 0x80 = 10000000
          } while (data[0] & 0x80); 
            
          if (ret == HAL_OK) {
              static float temp_c_max = -100.0f;
              static float temp_c_min = 100.0f;
              static float humidity_max = 0.0f;
              static float humidity_min = 100.0f;

              // 20 biti in total mut 8 biti pe bitii 19-12      aici mut pe 11-4        restul de 4
              uint32_t hum_raw = ((uint32_t)data[1] << 12) | ((uint32_t)data[2] << 4) | (data[3] >> 4);
              humidity = ((float)hum_raw * 100.0f) / 1048576.0f;

              // 20 biti in total  ultimii 4 din data[3] pe poz 19-16      aici mut pe 15-8      restul de 8
              uint32_t temp_raw = (((uint32_t)(data[3] & 0x0F)) << 16) | ((uint32_t)data[4] << 8) | data[5];
              temp_c = ((float)temp_raw * 200.0f / 1048576.0f) - 50.0f;
              
              if(temp_c > temp_c_max) temp_c_max = temp_c;
              if(temp_c < temp_c_min) temp_c_min = temp_c;
              if(humidity > humidity_max) humidity_max = humidity;
              if(humidity < humidity_min) humidity_min = humidity;

              printf("Temperature: %.2f C | Humidity: %.2f %%\r\n", temp_c, humidity);
          
              char buf[16];

              switch(display_mode) {
                case 0:  // Temperatura + umiditate
                  lcd_put_cursor(0, 0);
                  snprintf(buf, sizeof(buf), "Temp: %.2fC", temp_c);
                  lcd_send_string(buf);
                  lcd_put_cursor(1, 0);
                  snprintf(buf, sizeof(buf), "Hum: %.2f %%", humidity);
                  lcd_send_string(buf);
                  break;

                case 1:  // Doar temperatura
                  lcd_put_cursor(0, 0);
                  snprintf(buf, sizeof(buf), "Temp: %.2fC", temp_c);
                  lcd_send_string(buf);
                  lcd_put_cursor(1, 0);
                  snprintf(buf, sizeof(buf), "M:%.1fC m:%.1fC", temp_c_max, temp_c_min);
                  lcd_send_string(buf);  
                  break;

                case 2:  // Doar umiditate
                  lcd_put_cursor(0, 0);
                  snprintf(buf, sizeof(buf), "Hum: %.2f%%", humidity);
                  lcd_send_string(buf);
                  lcd_put_cursor(1, 0);
                  snprintf(buf, sizeof(buf), "M:%.1f%% m:%.1f%%", humidity_max, humidity_min);
                  lcd_send_string(buf);
                  break;

                case 3: // Doar viteza vantului
                  lcd_put_cursor(0, 0);
                  snprintf(buf, sizeof(buf), "Vv:%.1fkm/h", viteza_medie);
                  lcd_send_string(buf);
                  lcd_put_cursor(1, 0);
                  snprintf(buf, sizeof(buf), "M:%.1f m:%.1f", viteza_max, viteza_min);
                  lcd_send_string(buf);
                  break;
              }
              printf("RAW data: %02X %02X %02X %02X %02X %02X\r\n", data[0], data[1], data[2], data[3], data[4], data[5]);
          }
      }
     
      
      // am schimbat in makefile
      // in newlib-nano(biblioteca C folosita de STM32 pentru a salva memorie) nu e activat salvarea valorilor in memorie ca float
      // adica pe scurt fara sa scriem in makefile -u _printf_float el nu stie sa interpreteze rezultatele float

      if (led_on) {
        if (temp_c < 25.0f && SM_State != SM_SPEED_VARY_BLUE_BLINK) {
            printf("Temp < 25°C => SPEED_VARY_BLUE_BLINK\n");
            reset_led_effects();
            SM_State = SM_SPEED_VARY_BLUE_BLINK;
        } else if (temp_c >= 26.0f && SM_State != SM_BREATHE_RED) {
            printf("Temp >= 26°C => BREATHE_RED\n");
            reset_led_effects();
            SM_State = SM_BREATHE_RED;
        } else if (temp_c >= 25.0f && temp_c < 26.0f && SM_State != SM_FULL_GREEN) {
            printf("Temp între 25-26°C => FULL_GREEN\n");
            reset_led_effects();
            SM_State = SM_FULL_GREEN;
        }
      }
    } 
     
    switch(SM_State) {
      case SM_START:
        printf("Code version %d.%d starting...\n\r", SW_VERSION / 10, SW_VERSION % 10);
        break;

      case SM_FULL_GREEN:
        if (led_on) {
          variable_full_green = 1;
        }
        break;

      case SM_SPEED_VARY_BLUE_BLINK:
        if (led_on && !initialized_blue_blink) { // prima data cand intru in starea asta din trecea de la alta stare 
          variable_blink_blue = 1;
          blue_led_state = 0;
          blue_blink_ticks = 0;
          blue_blink_delay = BLUE_BLINK_MIN;
          blue_blink_dir = 1;
          initialized_blue_blink = 1;
        }
        break;

      case SM_BREATHE_RED:
        if (led_on && !initialized_breathe) {
          printf("Entered BREATHE_RED\n");
          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, 0); 
          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 0); 
          breathe_pwm = 0;
          breathe_dir = 1;
          breathe_mode = 1;
          __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 0);
          HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
          initialized_breathe = 1;
        }
        break;

      default:
        SM_State = SM_START;
    }

    static uint32_t last_measure_time = 0;
    static uint32_t pulse_history[3] = {0};
    static uint8_t index = 0;

    if (HAL_GetTick() - last_measure_time >= 1000)
    {
      last_measure_time = HAL_GetTick();

      pulse_history[index] = pulse_count;
      index = (index + 1) % 3; 
      pulse_count = 0;

      uint32_t total_pulses = pulse_history[0] + pulse_history[1] + pulse_history[2];

      float numar_pale = 3.0f;
      float diametru_cm = 8.0f;

      float rpm_instant = (pulse_history[(index + 2) % 3] / numar_pale) * 60.0f;
      float viteza_instant = 3.14f * diametru_cm * (pulse_history[(index + 2) % 3] / numar_pale) * 0.036f;

      float rpm_medie = (total_pulses / numar_pale) * 60.0f / 3.0f;
      viteza_medie = 3.14f * diametru_cm * (total_pulses / numar_pale / 3.0f) * 0.036f;

      printf("Instant: RPM = %.2f | Viteza = %.2f km/h\r\n", rpm_instant, viteza_instant);
      printf("Medie:   RPM = %.2f | Viteza = %.2f km/h\r\n", rpm_medie, viteza_medie);

      if(viteza_instant > viteza_max) viteza_max = viteza_instant;
      if(viteza_instant < viteza_min) viteza_min = viteza_instant;
    }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.ClockSpeed = 100000;
  hi2c2.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7199;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 100;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_OC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_TIMING;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_OC_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 255;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PB1 */
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB12 */
  GPIO_InitStruct.Pin = GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB14 */
  GPIO_InitStruct.Pin = GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PA8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if(GPIO_Pin == GPIO_PIN_13) { 
    if (!btn_locked && (HAL_GetTick() - last_press_time > 200)) { // daca nu este apasat virtual si au trecut 200ms de la ultima apasare reala (debounce)
      last_press_time = HAL_GetTick();
      btn_locked = 1; 
      led_on = !led_on;
      printf("LED toggled: %s\r\n", led_on ? "ON" : "OFF");

      if (led_on == 0) {
            breathe_mode = 0;
            variable_blink_blue = 0;
            variable_full_green = 0;
            HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_3);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 0); 
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, 0); 
            __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 0);
            SM_State = SM_START;
      }
    }
  }
  else if(GPIO_Pin == GPIO_PIN_12) {
    if (!btn_display_locked && (HAL_GetTick() - last_display_press_time > 200)) {
        last_display_press_time = HAL_GetTick();
        btn_display_locked = 1;

        display_mode++;
        if (display_mode > 3) display_mode = 0;

        display_mode_changed = 1;

        printf("Interrupt PB12: Display mode = %d\r\n", display_mode);
    }
  }

  if (GPIO_Pin == GPIO_PIN_14) {
    pulse_count++;
  }
}

void reset_led_effects(void) {
  breathe_mode = 0;
  variable_blink_blue = 0;
  variable_full_green = 0;
  initialized_breathe = 0;
  initialized_blue_blink = 0;

  HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_3);
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 0);

  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 0);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, 0);
}




/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
